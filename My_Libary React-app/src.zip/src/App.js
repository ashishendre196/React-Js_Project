import React from "react";
import Main from "./component/Main";
function App() {
  return (
    <>
    <Main/>
    </>
  );
}
 
export default App;
